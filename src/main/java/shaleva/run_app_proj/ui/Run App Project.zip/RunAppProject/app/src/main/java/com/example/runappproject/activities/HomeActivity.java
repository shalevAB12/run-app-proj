package com.example.runappproject.activities;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.IntentCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.example.runappproject.R;
import com.example.runappproject.data_models.User;
import com.example.runappproject.fragments.AccountFragment;
import com.example.runappproject.fragments.HistoryFragment;
import com.example.runappproject.fragments.RunFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeActivity extends AppCompatActivity {

    private TextView welcomeTxtV;
    private User user;
    private BottomNavigationView navbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.home), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        navbar = findViewById(R.id.bottom_navbar);

        navbar.setOnItemSelectedListener(item -> switchFragment(getFragmentOfItem(item)));

        if (savedInstanceState == null) {
            navbar.setSelectedItemId(R.id.nav_account);
        }



//        Intent intent = getIntent();
//        if (android.os.Build.VERSION.SDK_INT >= 33) {
//            this.user = getIntent().getSerializableExtra("USER", User.class);
//        } else {
//            this.user = (User) getIntent().getSerializableExtra("USER");
//        }
//
//        welcomeTxtV = findViewById(R.id.welcome_tv);
//        welcomeTxtV.setText("Welcome " + this.user.getUsername() + "!");
    }

    private Fragment getFragmentOfItem(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.nav_account) {
            return new AccountFragment();
        } else if (itemId == R.id.nav_run) {
            return new RunFragment();
        }

        return new HistoryFragment();
    }

    private boolean switchFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();

        return true;
    }
}