package com.example.runappproject.data_models;

public enum RunStatus {
    ACTIVE, FINISHED
}
