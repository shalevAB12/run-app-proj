package com.example.runappproject.data_models;

import java.util.List;

public class OptimizedRoute {

    private double totalDistance;

    private double totalReward;

    private List<Waypoint> path;

    private String polyline;

    public OptimizedRoute() {}

    public double getTotalDistance() {
        return totalDistance;
    }

    public double getTotalReward() {
        return totalReward;
    }

    public List<Waypoint> getPath() {
        return path;
    }

    public String getPolyline() { return polyline; }
}