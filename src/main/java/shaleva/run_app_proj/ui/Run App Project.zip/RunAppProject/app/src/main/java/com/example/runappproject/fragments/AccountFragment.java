package com.example.runappproject.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.runappproject.R;

 // ודא שהנתיב תואם לפרויקט שלך

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.runappproject.R;
import com.example.runappproject.activities.LoginActivity;
import com.example.runappproject.data_models.User;
import com.example.runappproject.utilities.UserObjectHolder;
import com.google.android.material.button.MaterialButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AccountFragment extends Fragment {

    private TextView tvInitial, tvName, tvEmail;
    private TextView tvWeight, tvHeight, tvBirth, tvJoined;
    private MaterialButton btnLogout;

    public AccountFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // קישור רכיבי הממשק
        tvInitial = view.findViewById(R.id.tv_avatar_initial);
        tvName = view.findViewById(R.id.tv_profile_name);
        tvEmail = view.findViewById(R.id.tv_profile_email);
        tvWeight = view.findViewById(R.id.tv_profile_weight);
        tvHeight = view.findViewById(R.id.tv_profile_height);
        tvBirth = view.findViewById(R.id.tv_profile_birth);
        tvJoined = view.findViewById(R.id.tv_profile_joined);
        btnLogout = view.findViewById(R.id.btn_logout);

        // שליפת המשתמש המחובר מהסינגלטון
        User currentUser = UserObjectHolder.getData();
        btnLogout.setOnClickListener(e -> {
            UserObjectHolder.destroy();
            Intent intent = new Intent(getContext(), LoginActivity.class);
            startActivity(intent);
        });

        if (currentUser != null) {
            populateUserData(currentUser);
        }

    }

    private void populateUserData(User user) {
        // הצגת שם ואימייל
        String username = user.getUsername();
        tvName.setText(username);
        tvEmail.setText(user.getEmail());

        // הצגת אות ראשונה בעיגול הפרופיל
        if (username != null && !username.isEmpty()) {
            tvInitial.setText(String.valueOf(username.charAt(0)).toUpperCase());
        }

        // עיצוב מספרים
        tvWeight.setText(String.format(Locale.getDefault(), "%.1f kg", user.getWeightKg()));
        tvHeight.setText(String.format(Locale.getDefault(), "%.0f cm", user.getHeightCm()));

        // המרת Timestamps לתאריכים קריאים
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

        if (user.getBirthDate() > 0) {
            tvBirth.setText(sdf.format(new Date(user.getBirthDate())));
        }

        if (user.getCreatedAt() > 0) {
            tvJoined.setText(sdf.format(new Date(user.getCreatedAt())));
        }
    }
}