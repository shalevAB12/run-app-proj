package com.example.runappproject.data_models;

public class RunDataPoint {
    private double latitude;
    private double longitude;
    private double altitude;
    private float speed;       // המהירות שהאנדרואיד מדד באותו רגע
    private long timestamp;    // זמן מדויק של הדגימה
    private float accuracy;    // רמת דיוק ה-GPS בנקודה זו
    private int stepDelta;
    private boolean isFirstPoint;

    public RunDataPoint() {}

    public RunDataPoint(double latitude, double longitude, double altitude, float speed, long timestamp, float accuracy, int stepDelta,boolean isFirstPoint) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.altitude = altitude;
        this.speed = speed;
        this.timestamp = timestamp;
        this.accuracy = accuracy;
        this.stepDelta = stepDelta;
        this.isFirstPoint = isFirstPoint;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public double getAltitude() {
        return altitude;
    }

    public float getSpeed() {
        return speed;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public float getAccuracy() {
        return accuracy;
    }

    public int getStepDelta() {
        return stepDelta;
    }

    public boolean isFirstPoint() {
        return isFirstPoint;
    }
}
