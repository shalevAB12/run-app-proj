package com.example.runappproject.activities;

import static android.widget.Toast.LENGTH_LONG;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.runappproject.R;
import com.example.runappproject.utilities.UIHelper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;


public class RunRecordingActivity extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap gMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private Polyline runningRoute;
    private Marker navigationMarker;
    private BitmapDescriptor arrowIcon;
    private final List<LatLng> pathPoints = new ArrayList<>();
    private boolean isInitializedLocation;
    private float totalDistanceInMeters; // מרחק מצטבר במטרים
    private Location lastLocationForDistance; // המיקום האחרון שחישבנו
    private TextView distanceTextView;
    public static final String[] REQUIRED_PERMISSIONS = new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    private static final int SECOND = 1000;
    private static final int TENTH_OF_SECOND = 100;
    private long startTime;
    private Handler timerHandler;
    private TextView timerTextView;
    private boolean isRunning;

    // Runnable שמבצע את עדכון הזמן
    private Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            long millis = SystemClock.elapsedRealtime() - startTime;
            int seconds = (int) (millis / 1000);
            int minutes = seconds / 60;
            int hours = minutes / 60;
            seconds = seconds % 60;
            minutes = minutes % 60;

            // עדכון הטקסט בפורמט 00:00:00
            timerTextView.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));

            // קריאה חוזרת לעצמו בעוד שנייה אחת
            timerHandler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_run_recording);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // map creating
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map_container);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        this.isInitializedLocation = true;
        this.totalDistanceInMeters = 0;
        this.distanceTextView = findViewById(R.id.passed_distance_tv);

        this.isRunning = false;
        this.timerHandler = new Handler(Looper.getMainLooper());
        this.timerTextView = findViewById(R.id.timer_tv);
        this.startTime = 0L;

        // initializing of the location provider
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.gMap = googleMap;
        this.arrowIcon = getBitmapFromVector(R.drawable.arrow);

        gMap.getUiSettings().setRotateGesturesEnabled(true);
        gMap.getUiSettings().setTiltGesturesEnabled(false);

        // initial focus on israel
        LatLng defaultLocation = new LatLng(31.5, 34.8);
        gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 7f));

        // defining the route line visuals
        PolylineOptions polylineOptions = new PolylineOptions()
                .color(Color.RED)
                .width(14f)
                .geodesic(true);

        runningRoute = gMap.addPolyline(polylineOptions);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, 1);
        }

        startTimer();
        trackLocationUpdates();
    }
    private void trackLocationUpdates() {
        // location request building - with high accuracy priority and update interval between 1 - 2 seconds
        LocationRequest locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, SECOND + 9 * TENTH_OF_SECOND)
                .setMinUpdateIntervalMillis(SECOND + 3 * TENTH_OF_SECOND)
                .build();

        // location callback creation - when location result/s are than - update them on the map
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {

                for (Location location : locationResult.getLocations()) {
                    updateMapUI(location);
                }
            }
        };

        // location access permissions check
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            // sending the request
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        }

        //Toast.makeText(RunRecordingActivity.this, "Something went wrong asf.", LENGTH_LONG).show();
    }

    private void updateMapUI(Location location) {
        // the location result pivots
        LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());

        // adding to the path and updating the route line.
        pathPoints.add(currentLatLng);
        runningRoute.setPoints(pathPoints);

        // if the navigation arrow doesn't exist - create him
        if (navigationMarker == null) {
            navigationMarker = gMap.addMarker(new MarkerOptions()
                    .position(currentLatLng)
                    .flat(true)
                    .anchor(0.5f, 0.5f)
                    .icon(arrowIcon));
        } else {
            navigationMarker.setPosition(currentLatLng);
        }

        // arrow rotation in real time
        if (location.hasBearing()) {
            navigationMarker.setRotation(location.getBearing());
        }

        // camera movement update
        if (isInitializedLocation) {
            gMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 17f));
            isInitializedLocation = false;
        }
        else {
            double distanceStep = lastLocationForDistance.distanceTo(location);

            if (distanceStep > 0.8) totalDistanceInMeters += distanceStep;
            gMap.moveCamera(CameraUpdateFactory.newLatLng(currentLatLng));
        }

        distanceTextView.setText(String.format("%.2f m", totalDistanceInMeters));
        lastLocationForDistance = location;
    }

    private BitmapDescriptor getBitmapFromVector(@DrawableRes int vectorResourceId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(this, vectorResourceId);
        if (vectorDrawable == null) return null;

        // 1. חישוב הגודל הדינמי (DP ל-PX)
        int sizeInPx = (int) (40 * getResources().getDisplayMetrics().density);

        // 2. יצירת ה-Bitmap בדיוק בגודל שחישבנו (sizeInPx) במקום הגודל המקורי
        Bitmap bitmap = Bitmap.createBitmap(sizeInPx, sizeInPx, Bitmap.Config.ARGB_8888);

        // 3. הצמדת ה-Drawable לקנבס
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        vectorDrawable.draw(canvas);

        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // עצירת המעקב כדי למנוע זליגת זיכרון ובזבוז סוללה
        if (fusedLocationClient != null && locationCallback != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults, int deviceId) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults, deviceId);

        if (requestCode == 1) { // ה-ID שנתת ב-requestPermissions
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // המשתמש אישר! עכשיו אפשר להתחיל לעבוד
                trackLocationUpdates();
            } else {
                // המשתמש סירב
                boolean showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION);

                if (!showRationale) {
                    // סירוב קבוע - הדיאלוג לא יקפוץ יותר. נשלח אותו להגדרות.
                    showSettingsDialog();
                } else {
                    // סירוב רגיל - אפשר להראות את הדיאלוג שלך ולבקש שוב
                    showPermissionRationaleDialog();
                }
            }
        }
    }
    private void showSettingsDialog() {
        AlertDialog.Builder builder = UIHelper.buildAlertDialog(this, "Permissions Permanently Denied", "You have permanently denied location permissions. Please enable them in the app settings to use the map.", true);

                builder.setPositiveButton("Go to Settings", (dialog, which) -> {
                    // פתיחת דף הגדרות האפליקציה
                    Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(android.net.Uri.fromParts("package", getPackageName(), null));
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
    private void showPermissionRationaleDialog() {
        AlertDialog.Builder builder = UIHelper.buildAlertDialog(RunRecordingActivity.this,
                "Permissions required", "You must give the required permissions to use the map.", false);

        builder.setPositiveButton("OK", (dialogInterface, i) -> {
            ActivityCompat.requestPermissions(RunRecordingActivity.this, REQUIRED_PERMISSIONS, 1);
        });
        builder.show();
    }
    private void startTimer() {
        if (!isRunning) {
            startTime = SystemClock.elapsedRealtime();
            timerHandler.postDelayed(timerRunnable, 0);
            isRunning = true;
        }
    }
}