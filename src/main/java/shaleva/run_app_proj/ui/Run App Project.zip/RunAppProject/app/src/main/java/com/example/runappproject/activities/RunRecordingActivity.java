package com.example.runappproject.activities;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.runappproject.R;
import com.example.runappproject.utilities.RESTCommunicationHelper;
import com.example.runappproject.utilities.RunTrackingService;
import com.example.runappproject.utilities.ServerEndpointsAPI;
import com.example.runappproject.utilities.UIHelper;
import com.example.runappproject.utilities.UserObjectHolder;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RunRecordingActivity extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap gMap;
    private Marker navigationMarker;
    private BitmapDescriptor arrowIcon;
    private boolean isInitializedLocation;

    private final List<Polyline> polylines = new ArrayList<>();
    private List<LatLng> currentPathSegment = new ArrayList<>();

    private TextView distanceTextView;
    private TextView timerTextView;
    private boolean isPaused = false;
    private MaterialButton pauseResumeButton;
    private MaterialButton stopButton;

    public static final String[] REQUIRED_PERMISSIONS = new String[]{
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.POST_NOTIFICATIONS,
            Manifest.permission.ACTIVITY_RECOGNITION
    };

    // הוסף בראש המחלקה יחד עם שאר המשתנים
    private ServerEndpointsAPI requestsClient = RESTCommunicationHelper.buildServerActionHTTPRequest();

    // החלף את הפונקציה הקיימת בקוד הבא:


    // מקלט (Receiver) שמאזין לעדכונים מהסרביס
    private final BroadcastReceiver runUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (RunTrackingService.ACTION_RUN_UPDATE.equals(intent.getAction())) {

                // קבלת המיקום בצורה בטוחה שתואמת למכשירים חדשים
                Location location;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    location = intent.getParcelableExtra("location", Location.class);
                } else {
                    location = intent.getParcelableExtra("location");
                }

                float distance = intent.getFloatExtra("distance", 0f);
                String timeString = intent.getStringExtra("timeString");

                // עדכון ה-UI
                if (location != null) {
                    updateMapUI(location);
                }
                distanceTextView.setText(String.format("%.2f m", distance));
                if (timeString != null) {
                    timerTextView.setText(timeString);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_run_recording);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map_container);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        this.isInitializedLocation = true;
        this.distanceTextView = findViewById(R.id.passed_distance_tv);
        this.timerTextView = findViewById(R.id.timer_tv);

        this.pauseResumeButton = findViewById(R.id.btn_pause_resume);
        this.stopButton = findViewById(R.id.btn_stop);

        this.pauseResumeButton.setOnClickListener(v -> togglePauseResume());
        this.stopButton.setOnClickListener(v -> stopRun());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // רישום המקלט כדי לקבל נתונים כשהאפליקציה על המסך
        IntentFilter filter = new IntentFilter(RunTrackingService.ACTION_RUN_UPDATE);
        ContextCompat.registerReceiver(this, runUpdateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // ביטול רישום המקלט כשהאפליקציה ברקע כדי לחסוך משאבי UI
        unregisterReceiver(runUpdateReceiver);
    }

    private void togglePauseResume() {
        Intent intent = new Intent(this, RunTrackingService.class);
        if (isPaused) {
            // מצב Resume
            intent.setAction(RunTrackingService.ACTION_RESUME);
            pauseResumeButton.setText("PAUSE");
            // כתום להשהיה
            pauseResumeButton.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF9800")));

            startNewPolylineSegment();
        } else {
            // מצב Pause
            intent.setAction(RunTrackingService.ACTION_PAUSE);
            pauseResumeButton.setText("RESUME");
            // ירוק להמשך
            pauseResumeButton.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#4CAF50")));
        }
        startService(intent);
        isPaused = !isPaused;
    }

    private void stopRun() {
        Intent intent = new Intent(this, RunTrackingService.class);
        stopService(intent); // זה יפעיל את ה-onDestroy בסרביס
        finish(); // סגירת המסך הנוכחי
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.gMap = googleMap;
        this.arrowIcon = getBitmapFromVector(R.drawable.arrow);

        gMap.getUiSettings().setRotateGesturesEnabled(true);
        gMap.getUiSettings().setTiltGesturesEnabled(false);

        LatLng defaultLocation = new LatLng(31.5, 34.8);
        gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 7f));

        startNewPolylineSegment();

        checkPermissionsAndStartService();
    }

    private void startNewPolylineSegment() {
        if (gMap == null) return;

        PolylineOptions polylineOptions = new PolylineOptions()
                .color(Color.RED)
                .width(14f)
                .geodesic(true);

        Polyline newPolyline = gMap.addPolyline(polylineOptions);
        polylines.add(newPolyline);
        currentPathSegment = new ArrayList<>(); // מאפסים את הרשימה למקטע החדש
    }


    private void startRunService() {
        // השתמש ב-ID האמיתי של המשתמש (כרגע Hardcoded לשם הדוגמה)
        String currentUserId = UserObjectHolder.getData().getEmail();

        requestsClient.startRun(currentUserId).enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String serverRunId = response.body();

                    // השרת אישר ויצר ריצה - עכשיו מפעילים את הסרביס עם ה-ID
                    Intent serviceIntent = new Intent(RunRecordingActivity.this, RunTrackingService.class);
                    serviceIntent.putExtra("RUN_ID", serverRunId);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(serviceIntent);
                    } else {
                        startService(serviceIntent);
                    }
                } else {
                    Toast.makeText(RunRecordingActivity.this, "שגיאה ביצירת ריצה בשרת", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Toast.makeText(RunRecordingActivity.this, "שגיאת תקשורת: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateMapUI(Location location) {
        LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());

        currentPathSegment.add(currentLatLng);
        if (!polylines.isEmpty()) {
            // מעדכנים רק את המקטע הנוכחי (האחרון ברשימה)
            polylines.get(polylines.size() - 1).setPoints(currentPathSegment);
        }

        if (navigationMarker == null) {
            navigationMarker = gMap.addMarker(new MarkerOptions()
                    .position(currentLatLng)
                    .flat(true)
                    .anchor(0.5f, 0.5f)
                    .icon(arrowIcon));
        } else {
            navigationMarker.setPosition(currentLatLng);
        }

        if (location.hasBearing()) {
            navigationMarker.setRotation(location.getBearing());
        }

        if (isInitializedLocation) {
            gMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 17f));
            isInitializedLocation = false;
        } else {
            gMap.moveCamera(CameraUpdateFactory.newLatLng(currentLatLng));
        }
    }

    private BitmapDescriptor getBitmapFromVector(@DrawableRes int vectorResourceId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(this, vectorResourceId);
        if (vectorDrawable == null) return null;

        int sizeInPx = (int) (40 * getResources().getDisplayMetrics().density);
        Bitmap bitmap = Bitmap.createBitmap(sizeInPx, sizeInPx, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        vectorDrawable.draw(canvas);

        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }



    private void checkPermissionsAndStartService() {
        boolean allPermissionsGranted = true;

        // לולאה שעוברת על כל ההרשאות שביקשנו ומקפידה שכולן מאושרות
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                break; // מספיק שהרשאה אחת חסרה כדי שנעצור ונבקש
            }
        }

        if (!allPermissionsGranted) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, 1);
        } else {
            startRunService();
        }
    }


}