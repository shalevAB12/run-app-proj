package com.example.runappproject.utilities;

import com.example.runappproject.data_models.User;

public class UserObjectHolder {
    private static User userObj;

    public static void setData(User user) {
        userObj = user;
    }

    public static User getData() {
        return userObj;
    }

    public static void destroy() { userObj = null; }
}
