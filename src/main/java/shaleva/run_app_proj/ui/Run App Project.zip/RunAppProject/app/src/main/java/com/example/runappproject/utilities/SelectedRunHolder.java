package com.example.runappproject.utilities;

import com.example.runappproject.data_models.RunSession;

public class SelectedRunHolder {
    private static RunSession selectedSession;

    public static void setData(RunSession session) {
        selectedSession = session;
    }

    public static RunSession getData() {
        return selectedSession;
    }

    public static void clear() {
        selectedSession = null;
    }
}
