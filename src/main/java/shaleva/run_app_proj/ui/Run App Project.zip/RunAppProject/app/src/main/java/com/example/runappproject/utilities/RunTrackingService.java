package com.example.runappproject.utilities;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.runappproject.R;
import com.example.runappproject.activities.RunRecordingActivity;
import com.example.runappproject.data_models.RunDataPoint;
import com.example.runappproject.data_models.RunDataSummary;
import com.example.runappproject.data_models.RunPointsUpdateRequestObject;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RunTrackingService extends Service implements SensorEventListener {

    public static final String ACTION_RUN_UPDATE = "com.example.runappproject.RUN_UPDATE";
    private static final String CHANNEL_ID = "RunTrackingChannel";
    private static final int NOTIFICATION_ID = 1;
    private static final int BATCH_INTERVAL_MS = 15000;
    public static final String ACTION_PAUSE = "ACTION_PAUSE";
    public static final String ACTION_RESUME = "ACTION_RESUME";

    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;

    private float totalDistanceInMeters = 0;
    private Location lastLocationForDistance;

    private Handler timerHandler;
    private long startTime;
    private boolean isRunning = false;
    private String currentTimerString = "00:00:00";

    // ניהול ה-Batch והתקשורת עם השמות החדשים
    private String currentRunId;
    private List<RunDataPoint> pointBatch; // שימוש ב-RunDataPoint
    private Handler networkHandler;

    private SensorManager sensorManager;
    private Sensor stepSensor;
    private int currentStepDelta = 0;

    private long totalPauseTime = 0;   // זמן מצטבר במילי-שניות שהיינו ב-Pause
    private long pauseStartTime = 0;   // מתי התחילה ההשהיה הנוכחית
    private boolean isPaused = false;
    private int pointsAfterResumeCount = 0;

    ServerEndpointsAPI requestsClient = RESTCommunicationHelper.buildServerActionHTTPRequest();
    @Override
    public void onCreate() {
        super.onCreate();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        timerHandler = new Handler(Looper.getMainLooper());
        networkHandler = new Handler(Looper.getMainLooper());
        pointBatch = new ArrayList<>();

        createNotificationChannel();

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        }

        registerStepSensor();
    }

    private void registerStepSensor() {
        if (stepSensor != null) {
            sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case ACTION_PAUSE:
                    pauseTracking();
                    break;
                case ACTION_RESUME:
                    resumeTracking();
                    break;
            }
        }

        // הטיפול ב-RUN_ID המקורי
        if (intent != null && intent.hasExtra("RUN_ID")) {
            currentRunId = intent.getStringExtra("RUN_ID");
        }

        if (!isRunning) {
            startForeground(NOTIFICATION_ID, createNotification());
            startTimer();
            trackLocationUpdates();
            startNetworkBatching();
            isRunning = true;
        }

        return START_STICKY;
    }

    private void pauseTracking() {
        if (!isPaused) {
            isPaused = true;
            pauseStartTime = SystemClock.elapsedRealtime();

            // עצירת GPS
            if (fusedLocationClient != null && locationCallback != null) {
                fusedLocationClient.removeLocationUpdates(locationCallback);
            }

            // תיקון חשוב: עצירת חיישן הצעדים
            if (sensorManager != null) {
                sensorManager.unregisterListener(this);
            }

            Log.d("RunTracking", "Everything paused (GPS & Steps)");
        }
    }

    private void resumeTracking() {
        if (isPaused) {
            totalPauseTime += (SystemClock.elapsedRealtime() - pauseStartTime);
            isPaused = false;
            lastLocationForDistance = null;
            pointsAfterResumeCount = 0; // מאפסים את המונה

            trackLocationUpdates();
            registerStepSensor();
            Log.d("RunTracking", "Everything resumed");
        }
    }

    private void trackLocationUpdates() {
        LocationRequest locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1700)
                .setMinUpdateIntervalMillis(1200)
                .build();

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                for (Location location : locationResult.getLocations()) {
                    processNewLocation(location);
                }
            }
        };

        try {
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    private void processNewLocation(Location location) {
        if (isPaused) return;

        // 1. פילטר דיוק - מתעלמים מנקודות עם סטייה גדולה מדי (מעל 20 מטר)
        if (location.getAccuracy() > 20) {
            return;
        }

        // משתנה שיסמן לשרת שזו נקודת התחלה של מקטע חדש (אחרי Resume)
        boolean isFirstPointForServer = false;

        // 2. טיפול במצב של אחרי Resume (תקופת חימום)
        if (pointsAfterResumeCount < 2) {
            pointsAfterResumeCount++;
            lastLocationForDistance = location;

            // אם זו הנקודה השנייה (הנקודה הראשונה שאנחנו ממש שולחים), נסמן אותה
            if (pointsAfterResumeCount == 2) {
                isFirstPointForServer = true;
            } else {
                // נקודה ראשונה ממש - רק משדרים ל-UI כדי שהמפה תתמרכז, אבל לא מוסיפים למרחק או לשרת
                Intent broadcastIntent = new Intent(ACTION_RUN_UPDATE);
                broadcastIntent.setPackage(getPackageName());
                broadcastIntent.putExtra("location", location);
                broadcastIntent.putExtra("distance", totalDistanceInMeters);
                broadcastIntent.putExtra("timeString", currentTimerString);
                sendBroadcast(broadcastIntent);
                return;
            }
        }

        // 3. חישוב המרחק באנדרואיד
        if (lastLocationForDistance != null && !isFirstPointForServer) {
            float distanceStep = lastLocationForDistance.distanceTo(location);

            // מניעת קפיצות GPS לא הגיוניות (מעל 20 מטר בשנייה זה יותר מ-70 קמ"ש)
            if (distanceStep < 20) {
                totalDistanceInMeters += distanceStep;
            }
        }

        // 4. יצירת הנקודה ושליחה ל-Batch (כולל השדה החדש isFirstPoint)
        RunDataPoint point = new RunDataPoint(
                location.getLatitude(),
                location.getLongitude(),
                location.getAltitude(),
                location.getSpeed(),
                location.getTime(),
                location.getAccuracy(),
                currentStepDelta,
                isFirstPointForServer // <--- השדה שהוספנו בשביל השרת
        );

        currentStepDelta = 0;
        pointBatch.add(point);

        lastLocationForDistance = location;

        // 5. שידור הנתונים המעודכנים ל-Activity כדי שה-UI יתעדכן
        Intent broadcastIntent = new Intent(ACTION_RUN_UPDATE);
        broadcastIntent.setPackage(getPackageName());
        broadcastIntent.putExtra("location", location);
        broadcastIntent.putExtra("distance", totalDistanceInMeters);
        broadcastIntent.putExtra("timeString", currentTimerString);
        sendBroadcast(broadcastIntent);
    }
    private void startNetworkBatching() {
        networkHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                sendBatchToServer();
                networkHandler.postDelayed(this, BATCH_INTERVAL_MS);
            }
        }, BATCH_INTERVAL_MS);
    }

    private void sendBatchToServer() {
        if (pointBatch.isEmpty() || currentRunId == null) return;

        // שכפול הרשימה וניקוי המקור
        List<RunDataPoint> pointsToSend = new ArrayList<>(pointBatch);
        pointBatch.clear();

        // יצירת אובייקט הבקשה החדש שלך
        RunPointsUpdateRequestObject requestObject = new RunPointsUpdateRequestObject();
        requestObject.setRunId(currentRunId);
        requestObject.setPoints(pointsToSend);

        requestsClient.sendDataPoints(requestObject).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (!response.isSuccessful()) {
                    Log.e("RunTracking", "Server error: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.e("RunTracking", "Network failure: " + t.getMessage());
            }
        });
    }
    private void startTimer() {
        startTime = SystemClock.elapsedRealtime();
        timerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                long activeMillis;
                long now = SystemClock.elapsedRealtime();

                if (!isPaused) {
                    // זמן פעיל = (עכשיו פחות התחלה) פחות זמן ההשהיות המצטבר
                    activeMillis = (now - startTime) - totalPauseTime;
                } else {
                    // אם אנחנו ב-Pause, הזמן "קופא" על הרגע שבו לחצנו Pause
                    activeMillis = (pauseStartTime - startTime) - totalPauseTime;
                }

                int seconds = (int) (activeMillis / 1000);
                int minutes = seconds / 60;
                int hours = minutes / 60;
                seconds = seconds % 60;
                minutes = minutes % 60;

                currentTimerString = String.format("%02d:%02d:%02d", hours, minutes, seconds);

                // שידור ל-Activity כדי לעדכן את ה-UI
                Intent broadcastIntent = new Intent(ACTION_RUN_UPDATE);
                broadcastIntent.setPackage(getPackageName()); // <--- השורה הקריטית למכשיר אמיתי!
                broadcastIntent.putExtra("timeString", currentTimerString);
                // שים לב: אנחנו שולחים גם את המרחק הנוכחי כדי שה-UI לא יתאפס
                broadcastIntent.putExtra("distance", totalDistanceInMeters);
                sendBroadcast(broadcastIntent);

                timerHandler.postDelayed(this, 1000);
            }
        }, 0);
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, RunRecordingActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Run Tracking Active")
                .setContentText("Your run is being recorded in the background.")
                .setSmallIcon(R.drawable.arrow) // החלף באייקון מתאים
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Run Tracking Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public void onDestroy() {
        // במידה והמשתמש עצר את הריצה כשהיא הייתה ב-Pause
        if (isPaused) {
            totalPauseTime += (SystemClock.elapsedRealtime() - pauseStartTime);
        }

        sendBatchToServer();

        if (currentRunId != null) {
            // שליחת ה-ID יחד עם זמן ההשהיה הכולל
            requestsClient.finishRun(currentRunId, totalPauseTime).enqueue(new Callback<RunDataSummary>() {
                @Override
                public void onResponse(Call<RunDataSummary> call, Response<RunDataSummary> response) {
                    if (response.isSuccessful()) {
                        Log.d("RunTracking", "Run finished with pause correction.");
                    }
                }

                @Override
                public void onFailure(Call<RunDataSummary> call, Throwable t) {
                    Log.e("RunTracking", "Failed to send final pause duration");
                }
            });
        }

        // 1. עצירת לולאות ה-Timer וה-Network כדי למנוע "רוחות רפאים" בריצה הבאה
        if (timerHandler != null) {
            timerHandler.removeCallbacksAndMessages(null);
        }
        if (networkHandler != null) {
            networkHandler.removeCallbacksAndMessages(null);
        }

        // 2. עצירת ה-GPS
        if (fusedLocationClient != null && locationCallback != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }

        // 3. עצירת האזנה לחיישן הצעדים
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }

        // ניקוי משאבים...
        stopForeground(true);
        super.onDestroy();
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null; // אנחנו משתמשים ב-Broadcast במקום Bind
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {}

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            // הוספת צעד למונה הזמני
            currentStepDelta++;
        }
    }
}
