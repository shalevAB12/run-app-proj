package com.example.runappproject.data_models;

public class RouteRequestObject {
    private double latitude;
    private double longitude;
    private double maxLength;

    public RouteRequestObject(double latitude, double longitude, double maxLength) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.maxLength = maxLength;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getMaxLength() {
        return maxLength;
    }

    public void setMaxLength(double maxLength) {
        this.maxLength = maxLength;
    }
}
