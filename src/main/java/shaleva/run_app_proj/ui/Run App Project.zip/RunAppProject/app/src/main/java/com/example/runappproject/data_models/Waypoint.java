package com.example.runappproject.data_models;

public class Waypoint {
    private double lat;

    private double lng;

    private String placeId;

    private double reward;

    private double distanceToNext;

    public Waypoint() {}
    public Waypoint(double lat, double lng, String placeId, double reward, double distanceToNext) {
        this.lat = lat;
        this.lng = lng;
        this.placeId = placeId;
        this.reward = reward;
        this.distanceToNext = distanceToNext;
    }

    public double getLat() { return lat; }
    public double getLng() { return lng; }
    public String getPlaceId() { return placeId; }
    public double getReward() { return reward; }
    public double getDistanceToNext() { return distanceToNext; }

}

