package com.example.runappproject.utilities;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

public class UIHelper {
    public static AlertDialog.Builder buildAlertDialog(@NonNull Context context, String title, String message, boolean isCancelable) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setCancelable(isCancelable);

        return builder;
    }
}
