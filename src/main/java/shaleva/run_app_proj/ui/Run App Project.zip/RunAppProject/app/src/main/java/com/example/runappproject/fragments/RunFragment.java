package com.example.runappproject.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.runappproject.R;
import com.example.runappproject.activities.RouteSetupActivity;
import com.example.runappproject.activities.RunRecordingActivity;

public class RunFragment extends Fragment {
    private Button startRunBtn;

    public RunFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_run, container, false);
        this.startRunBtn = view.findViewById(R.id.start_run_btn);

        startRunBtn.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), RouteSetupActivity.class);
            startActivity(intent);
        });

        return view;
    }

}