package com.example.runappproject.utilities;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.runappproject.R;
import com.example.runappproject.activities.RunStatisticsActivity;
import com.example.runappproject.data_models.RunDataPoint;
import com.example.runappproject.data_models.RunDataSummary;
import com.example.runappproject.data_models.RunSession;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.PolylineOptions;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class RunHistoryAdapter extends RecyclerView.Adapter<RunHistoryAdapter.RunViewHolder> {

    private final List<RunSession> runs;

    public RunHistoryAdapter(List<RunSession> runs) {
        this.runs = runs;
    }

    @NonNull
    @Override
    public RunViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_run_history, parent, false);
        return new RunViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RunViewHolder holder, int position) {
        RunSession session = runs.get(position);
        RunDataSummary summary = session.getSummary();

        // 1. תאריך
        if (session.getStartTime() > 0) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy | HH:mm", Locale.getDefault());
            holder.dateTv.setText(sdf.format(new Date(session.getStartTime())));
        }

        // 2. מדדים
        if (summary != null) {
            holder.distanceTv.setText(String.format(Locale.getDefault(), "%.2f", summary.getTotalDistanceKm()));
            holder.paceTv.setText(formatPace(summary.getAveragePace()));
            holder.timeTv.setText(formatDuration(summary.getDurationMillis()));
        }

        // 3. הצגת המפה
        holder.bindMap(session.getDataPoints());

        // 4. ---- האזנה ללחיצה ומעבר למסך סטטיסטיקות ----
        holder.detailsBtn.setOnClickListener(v -> {
            // שמירת הריצה הספציפית בזיכרון הזמני
            SelectedRunHolder.setData(session);

            // פתיחת המסך החדש
            Context context = v.getContext();
            Intent intent = new Intent(context, RunStatisticsActivity.class);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return runs != null ? runs.size() : 0;
    }

    // פונקציות עזר לעיצוב טקסט
    private String formatDuration(long millis) {
        int seconds = (int) (millis / 1000);
        int minutes = seconds / 60;
        int hours = minutes / 60;
        seconds = seconds % 60;
        minutes = minutes % 60;
        if (hours > 0) {
            return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);
        }
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    private String formatPace(double pace) {
        int minutes = (int) pace;
        int seconds = (int) ((pace - minutes) * 60);
        return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds);
    }

    // ה-ViewHolder (מוגדר כ-public כדי למנוע שגיאות חשיפה)
    public static class RunViewHolder extends RecyclerView.ViewHolder implements OnMapReadyCallback {
        MapView mapView;
        TextView dateTv, distanceTv, timeTv, paceTv, detailsBtn;
        GoogleMap map;
        List<RunDataPoint> currentPoints;

        public RunViewHolder(@NonNull View itemView) {
            super(itemView);
            mapView = itemView.findViewById(R.id.item_map_view);
            dateTv = itemView.findViewById(R.id.item_date_tv);
            distanceTv = itemView.findViewById(R.id.item_distance_tv);
            timeTv = itemView.findViewById(R.id.item_time_tv);
            paceTv = itemView.findViewById(R.id.item_pace_tv);
            detailsBtn = itemView.findViewById(R.id.item_details_btn);

            if (mapView != null) {
                mapView.onCreate(null);
                mapView.onResume();
                mapView.getMapAsync(this);
            }
        }

        public void bindMap(List<RunDataPoint> points) {
            this.currentPoints = points;
            if (map != null) updateMap();
        }

        @Override
        public void onMapReady(@NonNull GoogleMap googleMap) {
            this.map = googleMap;
            map.getUiSettings().setMapToolbarEnabled(false);
            updateMap();
        }

        private void updateMap() {
            if (map == null || currentPoints == null || currentPoints.isEmpty()) return;
            map.clear();
            PolylineOptions polylineOptions = new PolylineOptions().color(android.graphics.Color.RED).width(8f);
            LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
            boolean hasPoints = false;

            for (RunDataPoint point : currentPoints) {
                LatLng latLng = new LatLng(point.getLatitude(), point.getLongitude());
                polylineOptions.add(latLng);
                boundsBuilder.include(latLng);
                hasPoints = true;
            }

            map.addPolyline(polylineOptions);
            if (hasPoints) {
                map.moveCamera(CameraUpdateFactory.newLatLngBounds(boundsBuilder.build(), 50));
            }
        }
    }
}