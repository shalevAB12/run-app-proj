package com.example.runappproject.activities;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.runappproject.R;
import com.example.runappproject.data_models.RunDataPoint;
import com.example.runappproject.data_models.RunDataSummary;
import com.example.runappproject.data_models.RunSession;
import com.example.runappproject.utilities.SelectedRunHolder;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RunStatisticsActivity extends AppCompatActivity {

    private LineChart elevationChart, speedChart;
    private TextView tvDistance, tvTime, tvPace, tvCalories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_run_statistics);

        elevationChart = findViewById(R.id.chart_elevation);
        speedChart = findViewById(R.id.chart_speed);
        tvDistance = findViewById(R.id.tv_total_distance);
        tvTime = findViewById(R.id.tv_total_time);
        tvPace = findViewById(R.id.tv_avg_pace);
        tvCalories = findViewById(R.id.tv_calories);

        // משיכת האובייקט מהזיכרון הזמני (במקום Intent מנופח)
        RunSession session = SelectedRunHolder.getData();

        if (session != null) {
            updateUI(session);
        } else {
            Toast.makeText(this, "Error: Data not found", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void updateUI(RunSession session) {
        RunDataSummary summary = session.getSummary();

        // עדכון טקסטים
        if (summary != null) {
            tvDistance.setText(String.format(Locale.getDefault(), "%.2f KM", summary.getTotalDistanceKm()));
            tvTime.setText(formatDuration(summary.getDurationMillis()));
            tvPace.setText(formatPace(summary.getAveragePace()));

            // הערכת קלוריות (משקל כפול קילומטר, נניח ממוצע של 65)
            double burned = summary.getTotalDistanceKm() * 65;
            tvCalories.setText(String.format(Locale.getDefault(), "%.0f kcal", burned));
        }

        // שרטוט הגרפים
        setupElevationChart(session.getDataPoints());
        setupSpeedChart(session.getDataPoints());
    }

    private void setupElevationChart(List<RunDataPoint> points) {
        if (points == null || points.isEmpty()) return;

        List<Entry> entries = new ArrayList<>();
        long startTime = points.get(0).getTimestamp();

        for (RunDataPoint point : points) {
            float minutesPassed = (point.getTimestamp() - startTime) / 60000f;
            entries.add(new Entry(minutesPassed, (float) point.getAltitude()));
        }

        LineDataSet dataSet = new LineDataSet(entries, "Altitude");
        dataSet.setColor(Color.parseColor("#4CAF50"));
        dataSet.setLineWidth(2.5f);
        dataSet.setDrawCircles(false);
        dataSet.setDrawValues(false);
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        dataSet.setDrawFilled(true);
        dataSet.setFillColor(Color.parseColor("#C8E6C9"));

        com.github.mikephil.charting.components.YAxis leftAxis = elevationChart.getAxisLeft();
        leftAxis.resetAxisMinimum();
        elevationChart.setData(new LineData(dataSet));
        styleChart(elevationChart, "m");
    }

    private void setupSpeedChart(List<RunDataPoint> points) {
        if (points == null || points.isEmpty()) return;

        List<Entry> entries = new ArrayList<>();
        long startTime = points.get(0).getTimestamp();

        for (RunDataPoint point : points) {
            float minutesPassed = (point.getTimestamp() - startTime) / 60000f;
            float speedKmh = point.getSpeed() * 3.6f; // המרה לקמ"ש
            entries.add(new Entry(minutesPassed, speedKmh));
        }

        LineDataSet dataSet = new LineDataSet(entries, "Speed");
        dataSet.setColor(Color.parseColor("#2196F3"));
        dataSet.setLineWidth(2.5f);
        dataSet.setDrawCircles(false);
        dataSet.setDrawValues(false);
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        dataSet.setDrawFilled(true);
        dataSet.setFillColor(Color.parseColor("#BBDEFB"));

        speedChart.setData(new LineData(dataSet));
        styleChart(speedChart, "km/h");
    }

    private void styleChart(LineChart chart, String yAxisLabel) {
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);
        chart.getAxisRight().setEnabled(false); // צד ימין נשאר כבוי לנקיון ויזואלי

        // עיצוב ציר X (זמן)
        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(true);
        xAxis.setGridColor(Color.LTGRAY);
        xAxis.setTextColor(Color.DKGRAY);
        xAxis.setGranularity(1f); // מרווחים של דקה לפחות
        xAxis.setValueFormatter(new com.github.mikephil.charting.formatter.ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.getDefault(), "%.0f min", value);
            }
        });

        // עיצוב ציר Y (ערכים)
        com.github.mikephil.charting.components.YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setDrawGridLines(true);
        leftAxis.setGridColor(Color.LTGRAY);
        leftAxis.setTextColor(Color.DKGRAY);
        leftAxis.setValueFormatter(new com.github.mikephil.charting.formatter.ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.getDefault(), "%.1f %s", value, yAxisLabel);
            }
        });

        chart.setExtraOffsets(10, 10, 10, 10); // הוספת מרווח כדי שהטקסט לא ייחתך
        chart.invalidate();
    }

    private String formatDuration(long millis) {
        int seconds = (int) (millis / 1000);
        int minutes = seconds / 60;
        int hours = minutes / 60;
        seconds = seconds % 60;
        minutes = minutes % 60;
        if (hours > 0) return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    private String formatPace(double pace) {
        int minutes = (int) pace;
        int seconds = (int) ((pace - minutes) * 60);
        return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // מחיקת האובייקט מהזיכרון כשהמסך נסגר
        SelectedRunHolder.clear();
    }
}