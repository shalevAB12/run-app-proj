package com.example.runappproject.fragments;

import static com.example.runappproject.activities.RunRecordingActivity.REQUIRED_PERMISSIONS;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.runappproject.R;
import com.example.runappproject.activities.LoginActivity;
import com.example.runappproject.activities.RouteSetupActivity;
import com.example.runappproject.activities.RunRecordingActivity;
import com.example.runappproject.activities.SignupActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;
import com.google.maps.android.PolyUtil;

import java.util.List;


public class RoutePreviewFragment extends BottomSheetDialogFragment implements OnMapReadyCallback {
    private GoogleMap mMap;
    private TextView tvDistance, tvElevation;
    private MaterialButton startRecordingBtn;
    private CardView mapCard;

    private String mapPolyline;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_route_preview, container, false);
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        double dist = getArguments().getDouble("dist");
        String polyline = getArguments().getString("polyline");

        // אתחול רכיבי הטקסט
        tvDistance = view.findViewById(R.id.tv_total_distance);
        tvElevation = view.findViewById(R.id.tv_elevation_gain);
        mapCard = view.findViewById(R.id.map_card);
        startRecordingBtn = view.findViewById(R.id.btn_start_recording);
        startRecordingBtn.setOnClickListener(e -> startRunRecording());

        tvDistance.setText(dist + "");
        mapPolyline = polyline;

        // טעינת המפה
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map_fragment_container);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // --- פתרון התנגשות המחוות ---
        // 1. קודם כל, נשיג את ה-Behavior של הכרטיסייה (שים את זה ב-onViewCreated)
        View bottomSheet = (View) view.getParent();
        BottomSheetBehavior<View> behavior = BottomSheetBehavior.from(bottomSheet);

// 2. נעדכן את ה-Listener של ה-mapCard שלך
        mapCard.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    // ברגע שהאצבע יורדת על המפה - אנחנו נועלים את האפשרות לגרור את הכרטיסייה
                    behavior.setDraggable(false);
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    // ברגע שהאצבע מתרוממת או שהתנועה בוטלה - מחזירים את השליטה לכרטיסייה
                    behavior.setDraggable(true);
                    break;
            }

            // מחזירים false כדי שהמפה עצמה תמשיך לקבל את האירועים ותוכל לזוז/לעשות זום
            return false;
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // הגדרות בסיסיות למפה
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setAllGesturesEnabled(true);

        // כאן תוכל להוסיף את הלוגיקה לציור המסלול על המפה
        drawRouteAndZoom();
    }

    private void drawRouteAndZoom() {
        if (mapPolyline == null || mapPolyline.isEmpty()) return;

        // 1. פענוח המחרוזת לרשימה של נקודות ציון (LatLng)
        List<LatLng> decodedPath = PolyUtil.decode(mapPolyline);

        if (decodedPath.isEmpty()) return;

        // 2. ציור הקו על המפה
        PolylineOptions polylineOptions = new PolylineOptions()
                .addAll(decodedPath)
                .color(Color.parseColor("#4285F4")) // צבע כחול סטנדרטי למסלול
                .width(15f) // עובי הקו
                .geodesic(true); // עוקב אחרי הקימור של כדור הארץ (נראה טוב יותר בסיבובים)

        mMap.addPolyline(polylineOptions);

        // 3. הוספת סמנים (Markers) להתחלה ולסוף (אופציונלי אך משפר את המראה)
        mMap.addMarker(new MarkerOptions().position(decodedPath.get(0)).title("התחלה"));
        mMap.addMarker(new MarkerOptions().position(decodedPath.get(decodedPath.size() - 1)).title("סיום"));

        // 4. חישוב גבולות המסלול כדי שהמצלמה תעשה זום מתאים
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
        for (LatLng latLng : decodedPath) {
            boundsBuilder.include(latLng);
        }
        LatLngBounds bounds = boundsBuilder.build();

        // 5. הזזת המצלמה לגבולות שחישבנו עם מרווח (Padding) שוליים
        int padding = 100; // מרווח מהקצוות בפיקסלים כדי שהמסלול לא ייחתך

        // השתמשנו ב-setOnMapLoadedCallback כדי לוודא שהמפה סיימה להיטען לפני שמזיזים את המצלמה, 
        // אחרת זה עלול לקרוס כשהפרגמנט נפתח
        mMap.setOnMapLoadedCallback(() -> {
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, padding));
        });
    }
    
    private void startRunRecording() {
        Intent intent = new Intent(getActivity(), RunRecordingActivity.class);
        startActivity(intent);
        dismiss();
    }

}