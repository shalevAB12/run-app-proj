plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.runappproject"
    compileSdk {
        version = release(36) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "com.example.runappproject"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    implementation(libs.play.services.location)
    implementation(libs.fragment)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)

    implementation("com.squareup.retrofit2:retrofit:2.9.0")
// Converter להפיכת JSON לאובייקטים של Java (GSON)
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("com.squareup.retrofit2:converter-scalars:2.9.0")
// OkHttp (אופציונלי להוסיף ישירות אם רוצים להוסיף לוגים)
    implementation("com.squareup.okhttp3:logging-interceptor:4.9.1")

    implementation("com.google.android.gms:play-services-maps:18.2.0")
    // ספריית המיקום (GPS) של גוגל
    implementation("com.google.android.gms:play-services-location:21.0.1")

    implementation("com.google.android.material:material:1.13.0")
}