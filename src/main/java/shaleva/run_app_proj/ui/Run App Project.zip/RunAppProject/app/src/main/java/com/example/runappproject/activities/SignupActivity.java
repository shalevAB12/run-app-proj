package com.example.runappproject.activities;

import static android.widget.Toast.LENGTH_LONG;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.runappproject.R;
import com.example.runappproject.data_models.User;
import com.example.runappproject.utilities.RESTCommunicationHelper;
import com.example.runappproject.utilities.ServerEndpointsAPI;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class SignupActivity extends AppCompatActivity {

    // שינוי הטיפוסים לרכיבי ה-Material המפורשים
    private MaterialButton signupBtn;
    private TextInputEditText usernameETxt, emailETxt, passwordETxt, weightETxt, heightETxt, birthDateETxt;
    private long selectedBirthDateTimestamp = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.signup), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // האיתור (findViewById) נשאר זהה לחלוטין
        signupBtn = findViewById(R.id.signup_btn);
        usernameETxt = findViewById(R.id.UsernameET2);
        emailETxt = findViewById(R.id.EmailET2);
        passwordETxt = findViewById(R.id.passwordET2);
        weightETxt = findViewById(R.id.WeightET2);
        heightETxt = findViewById(R.id.HeightET2);
        birthDateETxt = findViewById(R.id.BirthDateET2);

        birthDateETxt.setOnClickListener(v -> showDatePicker());
        signupBtn.setOnClickListener(listener -> registerUser());
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR) - 20;
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            Calendar selectedCalendar = Calendar.getInstance();
            selectedCalendar.set(selectedYear, selectedMonth, selectedDay);
            selectedBirthDateTimestamp = selectedCalendar.getTimeInMillis();

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            birthDateETxt.setText(sdf.format(selectedCalendar.getTime()));
        }, year, month, day);

        datePickerDialog.show();
    }

    private void registerUser() {
        // שימוש ב-getText().toString() עובד פה בדיוק אותו דבר
        String username = usernameETxt.getText().toString().trim();
        String email = emailETxt.getText().toString().trim();
        String password = passwordETxt.getText().toString().trim();
        String weightStr = weightETxt.getText().toString().trim();
        String heightStr = heightETxt.getText().toString().trim();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || weightStr.isEmpty() || heightStr.isEmpty() || selectedBirthDateTimestamp == 0) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double weight;
        double height;
        try {
            weight = Double.parseDouble(weightStr);
            height = Double.parseDouble(heightStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight or height values", Toast.LENGTH_SHORT).show();
            return;
        }

        User userToRegister = new User(username, email, password, weight, height, selectedBirthDateTimestamp);
        ServerEndpointsAPI signupRequest = RESTCommunicationHelper.buildServerActionHTTPRequest();

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Creating your account...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        signupRequest.signup(userToRegister).enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                progressDialog.dismiss();
                int code = response.code();

                if (response.isSuccessful()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(SignupActivity.this);
                    builder.setTitle("Great! You have signed up successfully!");
                    builder.setMessage("Now login with your details.");
                    builder.setCancelable(false);

                    builder.setPositiveButton("OK", (dialogInterface, i) -> {
                        Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                } else {
                    Toast.makeText(SignupActivity.this, "Signup failed: " + code, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(SignupActivity.this, "Something went wrong with the connection", LENGTH_LONG).show();
            }
        });
    }

}