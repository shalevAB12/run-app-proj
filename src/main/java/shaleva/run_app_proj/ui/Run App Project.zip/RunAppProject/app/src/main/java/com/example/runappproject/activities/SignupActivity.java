package com.example.runappproject.activities;

import static android.widget.Toast.LENGTH_LONG;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.runappproject.R;
import com.example.runappproject.data_models.User;
import com.example.runappproject.utilities.RESTCommunicationHelper;
import com.example.runappproject.utilities.ServerEndpointsAPI;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class SignupActivity extends AppCompatActivity {

    private Button signupBtn;
    private EditText usernameETxt;
    private EditText passwordETxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.signup), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        signupBtn = findViewById(R.id.signup_btn);
        usernameETxt = findViewById(R.id.UsernameET2);
        passwordETxt = findViewById(R.id.passwordET2);
        signupBtn.setOnClickListener(listener -> registerUser());
    }

    private void registerUser() {
        String username = usernameETxt.getText().toString();
        String password = passwordETxt.getText().toString();
        User userToRegister = new User(username, password);
        ServerEndpointsAPI signupRequest = buildSignUpHTTPRequest();

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("searching and verifing user...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        signupRequest.signup(userToRegister).enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                progressDialog.dismiss();
                int code = response.code();

                if (response.isSuccessful()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(SignupActivity.this);

                    builder.setTitle("Great! You have signed up successfuly!");
                    builder.setMessage("Now login with your details.");
                    builder.setCancelable(false);

                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
                else {
                    Toast.makeText(SignupActivity.this, "): " + code, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(SignupActivity.this, "something went wrong", LENGTH_LONG).show();
            }
        });
    }

    private ServerEndpointsAPI buildSignUpHTTPRequest() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(RESTCommunicationHelper.SERVER_ADDRESS)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit.create(ServerEndpointsAPI.class);
    }
}