package com.example.runappproject.data_models;

public class RunDataSummary {
    private double totalDistanceKm;
    private long durationMillis;
    private double averagePace;
    private double totalElevationGain;
    private int totalSteps;

    public RunDataSummary() {}

    public double getTotalDistanceKm() {
        return totalDistanceKm;
    }

    public long getDurationMillis() {
        return durationMillis;
    }

    public double getAveragePace() {
        return averagePace;
    }

    public double getTotalElevationGain() {
        return totalElevationGain;
    }

    public int getTotalSteps() {
        return totalSteps;
    }
}
