package com.example.runappproject.utilities;

public class RESTCommunicationHelper {
    //"http://10.0.2.2:8080"
    //"https://color-headline-outer-hammer.trycloudflare.com"
    public static final String SERVER_ADDRESS = "http://10.0.2.2:8080";
}
