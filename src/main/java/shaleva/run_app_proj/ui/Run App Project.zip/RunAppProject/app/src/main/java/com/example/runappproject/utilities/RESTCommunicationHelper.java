package com.example.runappproject.utilities;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class RESTCommunicationHelper {
    //"http://10.0.2.2:8080"
    //"https://color-headline-outer-hammer.trycloudflare.com"
    public static final String SERVER_ADDRESS = "https://readers-suppliers-demonstration-could.trycloudflare.com";

    public static ServerEndpointsAPI buildServerActionHTTPRequest() {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(SERVER_ADDRESS)
                .client(okHttpClient)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit.create(ServerEndpointsAPI.class);
    }
}
