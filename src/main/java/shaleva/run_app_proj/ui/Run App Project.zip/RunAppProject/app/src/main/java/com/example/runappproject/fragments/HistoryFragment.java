package com.example.runappproject.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.runappproject.R;
import com.example.runappproject.data_models.RunSession;
import com.example.runappproject.utilities.RESTCommunicationHelper;
import com.example.runappproject.utilities.RunHistoryAdapter;
import com.example.runappproject.utilities.ServerEndpointsAPI;
import com.example.runappproject.utilities.UserObjectHolder;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HistoryFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private RunHistoryAdapter adapter;
    private final List<RunSession> runList = new ArrayList<>();

    // אובייקט התקשורת לשרת
    private ServerEndpointsAPI requestsClient;

    public HistoryFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 1. אתחול ה-Views
        recyclerView = view.findViewById(R.id.history_recycler_view);
        progressBar = view.findViewById(R.id.history_loader);

        requestsClient = RESTCommunicationHelper.buildServerActionHTTPRequest();

        // 2. הגדרת ה-RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new RunHistoryAdapter(runList);
        recyclerView.setAdapter(adapter);

        // 3. הבאת הנתונים
        fetchUserHistory();
    }

    private void fetchUserHistory() {
        progressBar.setVisibility(View.VISIBLE);
        String currentUserId = UserObjectHolder.getData().getEmail(); // החלף ב-ID האמיתי ששמור לך באפליקציה

        // הנחה: יש לך Endpoint בשרת שמחזיר List<RunSession>
        requestsClient.getUserHistory(currentUserId).enqueue(new Callback<List<RunSession>>() {
            @Override
            public void onResponse(@NonNull Call<List<RunSession>> call, @NonNull Response<List<RunSession>> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    runList.clear();
                    runList.addAll(response.body());
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(requireContext(), "Failed to load history", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<RunSession>> call, @NonNull Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(requireContext(), "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}