package com.example.runappproject.activities;

import static android.widget.Toast.LENGTH_LONG;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.runappproject.R;
import com.example.runappproject.data_models.User; // ודא שנתיב התיקייה תואם לשלך
import com.example.runappproject.utilities.RESTCommunicationHelper;
import com.example.runappproject.utilities.ServerEndpointsAPI;
import com.example.runappproject.utilities.UserObjectHolder;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {
    private MaterialButton loginBtn;
    private MaterialButton signupPassBtn;
    private TextInputEditText emailETxt; // הוחלף מ-usernameETxt
    private TextInputEditText passwordETxt;
    private TextView titleTxtV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // חיבור רכיבי הממשק (שים לב ש-EmailET מחליף את UsernameET)
        loginBtn = findViewById(R.id.login_btn);
        signupPassBtn = findViewById(R.id.signup_pass_btn);
        emailETxt = findViewById(R.id.EmailET);
        passwordETxt = findViewById(R.id.passwordET);

        // הגדרת הכותרת בצורה סטטית עברה ל-XML, אבל השארתי את הקישור למקרה שתרצה לשנות דינמית
        titleTxtV = findViewById(R.id.appTitleTV);

        loginBtn.setOnClickListener(e -> activateLogin());

        signupPassBtn.setOnClickListener(e -> {
            Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
            startActivity(intent);
        });
    }

    private void activateLogin() {
        String email = emailETxt.getText().toString().trim();
        String password = passwordETxt.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // יצירת אובייקט חלקי רק לצורך שליחת ה-Login לשרת
        User userToCheck = new User();
        userToCheck.setEmail(email);
        userToCheck.setPassword(password);

        ServerEndpointsAPI loginRequest = RESTCommunicationHelper.buildServerActionHTTPRequest();

        loginRequest.login(userToCheck).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                User userResponseResult = response.body();

                if (response.isSuccessful() && userResponseResult != null) {
                    UserObjectHolder userHolder = new UserObjectHolder();
                    UserObjectHolder.setData(userResponseResult);
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    startActivity(intent);
                    finish(); // סוגר את מסך ההתחברות כדי שלא יחזרו אליו עם כפתור ה-Back
                } else {
                    // מקרה של 401 או שגיאה אחרת (אימייל או סיסמה שגויים)
                    Toast.makeText(LoginActivity.this, "Invalid credentials. Please try again.", LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Toast.makeText(LoginActivity.this, "Network error. Please check your connection.", LENGTH_LONG).show();
            }
        });
    }
}