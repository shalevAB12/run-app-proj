package com.example.runappproject.activities;

import static android.widget.Toast.LENGTH_LONG;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.runappproject.R;
import com.example.runappproject.data_models.User;
import com.example.runappproject.utilities.RESTCommunicationHelper;
import com.example.runappproject.utilities.ServerEndpointsAPI;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {
    private Button loginBtn;
    private Button signupPassBtn;
    private EditText usernameETxt;
    private EditText passwordETxt;
    private TextView titleTxtV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        loginBtn = findViewById(R.id.login_btn);
        signupPassBtn = findViewById(R.id.signup_pass_btn);
        usernameETxt = findViewById(R.id.UsernameET);
        passwordETxt = findViewById(R.id.passwordET);
        titleTxtV = findViewById(R.id.appTitleTV);
        titleTxtV.setText("Login Page");

        loginBtn.setOnClickListener(e -> activateLogin());
        signupPassBtn.setOnClickListener(e -> {
            Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
            startActivity(intent);
        });
    }

    private void activateLogin() {
        String username = usernameETxt.getText().toString();
        String password = passwordETxt.getText().toString();
        User userToCheck = new User(username, password);
        ServerEndpointsAPI loginRequest = buildLoginHTTPRequest();

        loginRequest.login(userToCheck).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                User userResponseResult = response.body();
                if (response.isSuccessful() && userResponseResult != null) {
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    intent.putExtra("USER", userResponseResult);
                    startActivity(intent);
                }
                else if (response.isSuccessful()) {
                    Toast.makeText(LoginActivity.this, "U are out.", LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Toast.makeText(LoginActivity.this, "Something went wrong asf.", LENGTH_LONG).show();
            }
        });
    }

    private ServerEndpointsAPI buildLoginHTTPRequest() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(RESTCommunicationHelper.SERVER_ADDRESS)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit.create(ServerEndpointsAPI.class);
    }

}