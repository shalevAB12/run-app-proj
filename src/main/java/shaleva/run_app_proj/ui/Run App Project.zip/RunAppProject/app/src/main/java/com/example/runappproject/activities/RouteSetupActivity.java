package com.example.runappproject.activities;

import static android.widget.Toast.LENGTH_LONG;

import static com.example.runappproject.activities.RunRecordingActivity.REQUIRED_PERMISSIONS;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.runappproject.R;
import com.example.runappproject.data_models.OptimizedRoute;
import com.example.runappproject.data_models.RouteRequestObject;
import com.example.runappproject.fragments.RoutePreviewFragment;
import com.example.runappproject.utilities.RESTCommunicationHelper;
import com.example.runappproject.utilities.ServerEndpointsAPI;
import com.example.runappproject.utilities.UIHelper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RouteSetupActivity extends AppCompatActivity {

    private MaterialButton btnStart;
    private Slider sliderDistance, sliderElevation;
    private MaterialSwitch switchCustomized;
    private MaterialSwitch switchCircular;
    private LatLng userLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_route_setup);

        // קישור הרכיבים מה-XML
        btnStart = findViewById(R.id.btnStartAction);
        sliderDistance = findViewById(R.id.sliderDistance);
        sliderDistance.setLabelFormatter(value -> {
            return String.format("%.1f km", value);
        });

        sliderElevation = findViewById(R.id.sliderElevation);
        switchCircular = findViewById(R.id.switchCircular);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.route_setup), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        switchCustomized = findViewById(R.id.switchCustomized);
        LinearLayout layoutConstraints = findViewById(R.id.layoutConstraints);


        btnStart.setOnClickListener(e -> checkPermissionsAndStartRunAction());

        switchCustomized.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // קריאה לפונקציית העזר שלנו
            toggleViewHierarchy(layoutConstraints, isChecked);
            // שינוי שקיפות כדי לתת פידבק ויזואלי שהאזור חסום
            layoutConstraints.setAlpha(isChecked ? 1.0f : 0.5f);
        });
    }

    private void getOptimizedRouteFromServer() {
        // 1. קודם כל נפתח את הדיאלוג
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("משיג מיקום ומחשב מסלול...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        // 2. נשיג את המיקום
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // בדיקת הרשאות (כמו שעשית)
        boolean allGranted = true;

// עוברים על כל הרשימה שהגדרת למעלה
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break; // מספיק שאחת חסרה כדי שנסמן שצריך לבקש
            }
        }

        if (!allGranted) {
            // אם לפחות אחת חסרה, נבקש את כולן (אנדרואיד כבר יציג רק את מה שצריך)
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, 1);
            if (progressDialog != null) progressDialog.dismiss();
            return;
        }

        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, new CancellationTokenSource().getToken())
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        // 3. רק עכשיו, בתוך ה-Listener, יש לנו מיקום בטוח!
                        userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                        // נשלח לשרת
                        sendRequestToServer(progressDialog);
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(this, "לא הצלחנו למצוא את המיקום שלך", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "שגיאה ב-GPS", Toast.LENGTH_SHORT).show();
                });
    }

    // הפרדתי את הקריאה לשרת לפונקציה נפרדת כדי שהקוד יהיה קריא
    private void sendRequestToServer(ProgressDialog progressDialog) {
        ServerEndpointsAPI routeRequest = RESTCommunicationHelper.buildServerActionHTTPRequest();

        // חילוץ הערכים (המרחק מהסליידר כפול 1000 כדי להפוך למטרים)
        double distInMeters = sliderDistance.getValue() * 1000;

        System.out.println(userLocation.latitude);
        System.out.println(userLocation.longitude);
        System.out.println(distInMeters);

        routeRequest.generateRoute(new RouteRequestObject(userLocation.latitude, userLocation.longitude, distInMeters, switchCircular.isChecked()))
                .enqueue(new Callback<OptimizedRoute>() {
                    @Override
                    public void onResponse(Call<OptimizedRoute> call, Response<OptimizedRoute> response) {
                        progressDialog.dismiss();
                        if (response.isSuccessful() && response.body() != null) {
                            showRoutePreviewOnMap(response.body());
                        } else {
                            Toast.makeText(RouteSetupActivity.this, "שגיאה מהשרת: " + response.code(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<OptimizedRoute> call, Throwable t) {
                        // השורה הזו תדפיס לך באדום ב-Logcat בדיוק למה זה קרס
                        android.util.Log.e("RetrofitError", "הבקשה נכשלה בגלל: " + t.getMessage(), t);
                        Toast.makeText(RouteSetupActivity.this, "תקלת תקשורת", Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void showRoutePreviewOnMap(OptimizedRoute route) {
        RoutePreviewFragment mapSheet = new RoutePreviewFragment();

        // העברת הנתונים שהתקבלו מהשרת לתוך הכרטיסייה
        Bundle args = new Bundle();
        args.putDouble("dist", route.getTotalDistance());
        args.putString("polyline", route.getPolyline());
        // כאן תוכל להעביר גם את נקודות המסלול (Polyline) אם יש לך
        mapSheet.setArguments(args);

        mapSheet.show(getSupportFragmentManager(), "MapPreview");
    }

    private void toggleViewHierarchy(ViewGroup viewGroup, boolean isEnabled) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);

            // השבתת הרכיב עצמו
            child.setEnabled(isEnabled);

            // אם הרכיב הוא בעצמו קבוצת רכיבים (כמו ChipGroup או LinearLayout פנימי)
            // נבצע קריאה חוזרת (רקורסיה) כדי להשבית גם את הילדים שלו
            if (child instanceof ViewGroup) {
                toggleViewHierarchy((ViewGroup) child, isEnabled);
            }
        }
    }

    private void startRunRecording() {
        Intent intent = new Intent(this, RunRecordingActivity.class);
        startActivity(intent);
        finish();
    }

    public void checkPermissionsAndStartRunAction() {
        boolean allPermissionsGranted = true;

        // לולאה שעוברת על כל ההרשאות שביקשנו ומקפידה שכולן מאושרות
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                break; // מספיק שהרשאה אחת חסרה כדי שנעצור ונבקש
            }
        }

        if (!allPermissionsGranted) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, 1);
        } else {
            if (switchCustomized.isChecked()) getOptimizedRouteFromServer();
            else startRunRecording();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults, int deviceId) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults, deviceId);

        if (requestCode == 1) {
            boolean allGranted = grantResults.length > 0;

            // בודקים שכל התוצאות שחזרו הן PERMISSION_GRANTED
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                if (switchCustomized.isChecked()) getOptimizedRouteFromServer();
                else startRunRecording();
            } else {
                // אם המשתמש סירב, נבדוק את ההסבר (Rationale) עבור המיקום או החיישנים
                boolean showLocationRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION);
                boolean showActivityRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACTIVITY_RECOGNITION);

                // אם המשתמש סימן "אל תשאל שוב" באחת מההרשאות המרכזיות, נשלח אותו להגדרות
                if (!showLocationRationale && !showActivityRationale) {
                    showSettingsDialog();
                } else {
                    showPermissionRationaleDialog();
                }
            }
        }
    }

    private void showSettingsDialog() {
        AlertDialog.Builder builder = UIHelper.buildAlertDialog(this, "Permissions Permanently Denied", "You have permanently denied location permissions. Please enable them in the app settings to use the map.", true);
        builder.setPositiveButton("Go to Settings", (dialog, which) -> {
            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(android.net.Uri.fromParts("package", getPackageName(), null));
            startActivity(intent);
        }).setNegativeButton("Cancel", null).show();
    }

    private void showPermissionRationaleDialog() {
        AlertDialog.Builder builder = UIHelper.buildAlertDialog(RouteSetupActivity.this,
                "Permissions required", "You must give the required permissions to use the map.", false);
        builder.setPositiveButton("OK", (dialogInterface, i) -> {
            ActivityCompat.requestPermissions(RouteSetupActivity.this, REQUIRED_PERMISSIONS, 1);
        });
        builder.show();
    }
}