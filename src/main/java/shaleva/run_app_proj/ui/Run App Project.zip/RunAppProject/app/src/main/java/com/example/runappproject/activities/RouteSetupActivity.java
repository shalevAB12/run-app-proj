package com.example.runappproject.activities;

import static android.widget.Toast.LENGTH_LONG;

import static com.example.runappproject.activities.RunRecordingActivity.REQUIRED_PERMISSIONS;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.runappproject.R;
import com.example.runappproject.data_models.OptimizedRoute;
import com.example.runappproject.data_models.RouteRequestObject;
import com.example.runappproject.data_models.Waypoint;
import com.example.runappproject.fragments.RoutePreviewFragment;
import com.example.runappproject.utilities.RESTCommunicationHelper;
import com.example.runappproject.utilities.ServerEndpointsAPI;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class RouteSetupActivity extends AppCompatActivity {

    private MaterialButton btnStart;
    private Slider sliderDistance, sliderElevation;
    private MaterialSwitch switchCircular;
    private LatLng userLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_route_setup);

        // קישור הרכיבים מה-XML
        btnStart = findViewById(R.id.btnStartAction);
        sliderDistance = findViewById(R.id.sliderDistance);
        sliderDistance.setLabelFormatter(value -> {
            return String.format("%.1f km", value);
        });

        sliderElevation = findViewById(R.id.sliderElevation);
        switchCircular = findViewById(R.id.switchCircular);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.route_setup), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnStart.setOnClickListener(e -> getOptimizedRouteFromServer());
    }

    private void getOptimizedRouteFromServer() {
        // 1. קודם כל נפתח את הדיאלוג
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("משיג מיקום ומחשב מסלול...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        // 2. נשיג את המיקום
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // בדיקת הרשאות (כמו שעשית)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, 1);
            progressDialog.dismiss();
            return;
        }

        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, new CancellationTokenSource().getToken())
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        // 3. רק עכשיו, בתוך ה-Listener, יש לנו מיקום בטוח!
                        userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                        // נשלח לשרת
                        sendRequestToServer(progressDialog);
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(this, "לא הצלחנו למצוא את המיקום שלך", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "שגיאה ב-GPS", Toast.LENGTH_SHORT).show();
                });
    }

    // הפרדתי את הקריאה לשרת לפונקציה נפרדת כדי שהקוד יהיה קריא
    private void sendRequestToServer(ProgressDialog progressDialog) {
        ServerEndpointsAPI routeRequest = RESTCommunicationHelper.buildServerActionHTTPRequest();

        // חילוץ הערכים (המרחק מהסליידר כפול 1000 כדי להפוך למטרים)
        double distInMeters = sliderDistance.getValue() * 1000;

        System.out.println(userLocation.latitude);
        System.out.println(userLocation.longitude);
        System.out.println(distInMeters);

        routeRequest.generateRoute(new RouteRequestObject(userLocation.latitude, userLocation.longitude, distInMeters))
                .enqueue(new Callback<OptimizedRoute>() {
                    @Override
                    public void onResponse(Call<OptimizedRoute> call, Response<OptimizedRoute> response) {
                        progressDialog.dismiss();
                        if (response.isSuccessful() && response.body() != null) {
                            showRoutePreviewOnMap(response.body());
                        } else {
                            Toast.makeText(RouteSetupActivity.this, "שגיאה מהשרת: " + response.code(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<OptimizedRoute> call, Throwable t) {
                        // השורה הזו תדפיס לך באדום ב-Logcat בדיוק למה זה קרס
                        android.util.Log.e("RetrofitError", "הבקשה נכשלה בגלל: " + t.getMessage(), t);
                        Toast.makeText(RouteSetupActivity.this, "תקלת תקשורת", Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void getUserCurrentLocation() {
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, 1);
        }
        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, new CancellationTokenSource().getToken())
                .addOnSuccessListener(location -> {
                    userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                });
    }

    private void showRoutePreviewOnMap(OptimizedRoute route) {
        RoutePreviewFragment mapSheet = new RoutePreviewFragment();

        // העברת הנתונים שהתקבלו מהשרת לתוך הכרטיסייה
        Bundle args = new Bundle();
        args.putDouble("dist", route.getTotalDistance());
        args.putString("polyline", route.getPolyline());
        // כאן תוכל להעביר גם את נקודות המסלול (Polyline) אם יש לך
        mapSheet.setArguments(args);

        mapSheet.show(getSupportFragmentManager(), "MapPreview");
    }
}