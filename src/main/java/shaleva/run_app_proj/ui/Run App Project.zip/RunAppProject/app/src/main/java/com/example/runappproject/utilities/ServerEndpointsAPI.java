package com.example.runappproject.utilities;

import com.example.runappproject.data_models.OptimizedRoute;
import com.example.runappproject.data_models.RouteRequestObject;
import com.example.runappproject.data_models.RunDataSummary;
import com.example.runappproject.data_models.RunPointsUpdateRequestObject;
import com.example.runappproject.data_models.RunSession;
import com.example.runappproject.data_models.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ServerEndpointsAPI {
    @POST("/api/login")
    Call<User> login(@Body User user);

    @POST("/api/signup")
    Call<String> signup(@Body User user);

    @POST("/api/generate_route")
    Call<OptimizedRoute> generateRoute(@Body RouteRequestObject requestObject);

    @POST("/api/start")
    Call<String> startRun(@Query("userId") String userId);

    @POST("/api/finish")
    Call<RunDataSummary> finishRun(
            @Query("runId") String runId,
            @Query("pauseDurationMillis") long pauseDurationMillis);
    @POST("/api/update_points")
    Call<Void> sendDataPoints(@Body RunPointsUpdateRequestObject requestObject);

    @POST("/api/history") // עדכן לנתיב האמיתי בשרת שלך
    Call<List<RunSession>> getUserHistory(@Query("userId") String userId);
}
