package com.example.runappproject.utilities;

import com.example.runappproject.data_models.OptimizedRoute;
import com.example.runappproject.data_models.RouteRequestObject;
import com.example.runappproject.data_models.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ServerEndpointsAPI {
    @POST("/api/login")
    Call<User> login(@Body User user);

    @POST("/api/signup")
    Call<String> signup(@Body User user);

    @POST("/api/generate_route")
    Call<OptimizedRoute> generateRoute(@Body RouteRequestObject request);
}
